import { Component, Input, OnInit } from '@angular/core';
import { Question } from '../models/question';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.scss']
})
export class QuestionComponent implements OnInit {

  @Input()
  questiondata:Question;
  @Input()
  mode:string;
  constructor() { }

  ngOnInit(): void {
  }

  isselected()
  {
    let nb=this.questiondata.options.filter(x=> x.isSelected==true).length;
    if(nb==0)
       {
         this.questiondata.answered=false;
         
       }
    else
    {
    this.questiondata.answered=true;
   
    }
    return this.questiondata.answered;
  }
}
