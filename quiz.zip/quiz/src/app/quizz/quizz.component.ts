import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quizz',
  templateUrl: './quizz.component.html',
  styleUrls: ['./quizz.component.scss']
})
export class QuizzComponent implements OnInit {
 quiz=
 {
   "id":1,
   "name":"Angular",
   "desc":"ANGULAR FOR BEGINNERS",
   "question":[
     {
       "id":1,
       "quest":"11*11",
       "reponse":[
         {
           "id":1,
           "reponse":"111",
           "isCorrect":false
         },
         {
          "id":1,
          "reponse":"121",
          "isCorrect":true
        },
        {
          "id":1,
          "reponse":"122",
          "isCorrect":false
        }
       ]
    },
    {
      "id":1,
      "quest":"12*12",
      "reponse":[
        {
          "id":1,
          "reponse":"122",
          "isCorrect":false
        },
        {
         "id":1,
         "reponse":"144",
         "isCorrect":true
       },
       {
         "id":1,
         "reponse":"166",
         "isCorrect":false
       }
      ]
   },
   {
    "id":1,
    "quest":"13*13",
    "reponse":[
      {
        "id":1,
        "reponse":"199",
        "isCorrect":false
      },
      {
       "id":1,
       "reponse":"166",
       "isCorrect":true
     },
     {
       "id":1,
       "reponse":"169",
       "isCorrect":false
     }
    ]
 }
   ]

 };
  constructor() { }

  ngOnInit(): void {
  }

}
