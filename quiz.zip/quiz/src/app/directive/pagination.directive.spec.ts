import { PaginationDirective } from './pagination.directive';

describe('PaginationDirective', () => {
  it('should create an instance', () => {
    const directive = new PaginationDirective();
    expect(directive).toBeTruthy();
  });
});
