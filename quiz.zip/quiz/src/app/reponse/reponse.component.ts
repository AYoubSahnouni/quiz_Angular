import { Component, Input, OnInit } from '@angular/core';
import { reponse } from '../models/reponse';

@Component({
  selector: 'app-reponse',
  templateUrl: './reponse.component.html',
  styleUrls: ['./reponse.component.scss']
})
export class ReponseComponent implements OnInit {
bb:boolean=false;
  @Input()
  reponsedata:reponse;


  constructor() {


   }

  ngOnInit(): void {


  }

  pp(x:any)
  {
    this.bb=!this.bb;

  }
}
