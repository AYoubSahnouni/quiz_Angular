import { TestBed } from '@angular/core/testing';

import { CalculerService } from './calculer.service';

describe('CalculerService', () => {
  let service: CalculerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
