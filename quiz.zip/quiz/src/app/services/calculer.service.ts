import { reponse } from './../models/reponse';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculerService {

  constructor(private reponse:reponse) { }

  count = 0;

  calculer(){
    this.reponse.isSelected == true

    this.count +=1

  }




}
